import { producto } from "./productos";

export const PRODUCTOS: producto[] = [
    { id: 1, nombre: "Tomate", caducidad: "12232020", precio: 1 },
    { id: 2, nombre: "Leche", caducidad: "12232020", precio: 2 },
    { id: 3, nombre: "Queso", caducidad: "12232020", precio: 3 },
    { id: 4, nombre: "Patatas", caducidad: "12232020", precio: 4 },
    { id: 5, nombre: "Zanahoria", caducidad: "12232020", precio: 5 },
    { id: 6, nombre: "Carne", caducidad: "12232020", precio: 6 },
    { id: 7, nombre: "Yogurt", caducidad: "12232020", precio: 7 },
    { id: 8, nombre: "Huevos", caducidad: "12232020", precio: 8 },
    { id: 9, nombre: "Pan", caducidad: "12232020", precio: 9 },
    { id: 10, nombre: "Pollo", caducidad: "12232020", precio: 10 },
    { id: 11, nombre: "Pescado", caducidad: "12232020", precio: 11 }
]