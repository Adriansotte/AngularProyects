import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fecha'
})
export class FechaPipe implements PipeTransform {

  transform(value: String, ...args: unknown[]): unknown {
    const fecha = value.substring(0, 2) + "/" +  value.substring(2, 4) + "/" +
    value.substring(4, 8)
    return fecha;
  }

}
