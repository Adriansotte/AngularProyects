import { Component } from '@angular/core';
import { PRODUCTOS } from './mock-productos';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'marketPlace';
  productos = PRODUCTOS;
}
