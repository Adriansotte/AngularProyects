export interface producto {
    id: number;
    nombre: String;
    caducidad: String;
    precio: number;
}